<nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="100" id="sectionsNav">
 
            <div class="container-fluid">
              <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto ">
                  <li class="nav-item mr-3">
                    <a href="javascript:;" class="btn btn-link btn-raised btn-fab " data-toggle="dropdown" style="margin-top: -20px;">
                    <img src="image/apps.png" alt="" style="opacity: .5;width:25px; height:25px;">
                    </a>
                  </li>
                  <li class="dropdown nav-item mr-2">
                    <a href="javascript:;" class="profile-photo dropdown-toggle nav-link" data-toggle="dropdown">
                      <div class="profile-photo-small">
                        <img src="image/profil.jpg" style="width:30px; height:30px;" alt="Circle Image" class="rounded-circle img-fluid">
                      </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <h6 class="dropdown-header">Dropdown header</h6>
                      <a href="javascript:;" class="dropdown-item">Me</a>
                      <a href="javascript:;" class="dropdown-item">Settings and other stuff</a>
                      <a href="javascript:;" class="dropdown-item">Sign out</a>
                    </div>
                  </li>
                </ul>
              </div><!-- /.navbar-collapse -->
            </div><!-- /.container-->
          </nav>