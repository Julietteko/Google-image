<nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="100" id="sectionsNav" style="height: 60px;">
    <div class="container-fluid" >
      <div class="navbar-translate position-relative mt-4">
        
          <img src="image/google.png" class="position-relative img" style="margin-top: -30px;cursor: pointer;" alt=""  height="45px"> 
        
        <form action="search.php" method="POST" class="position-absolute" >
            <input type="text" class="pl-5 box" name="search" value="<?php echo $search ?>" style="position:relative;padding-right: 130px;margin-top: -40px; height: 40px;margin-left:150px; width: 700px;" >
            <i class="material-icons text-dark loup" style="position:absolute; margin-top:-80px; margin-left:150px;opacity: 0.5;display:none">search</i>
            <i class="material-icons text-dark" style="opacity:.7;position:absolute; margin-top:-80px; margin-left:720px;">camera_alt</i>
            <img src="image/mic.png" alt="" width="15px" height="23px" style="position:absolute; margin-top:-80px; margin-left:770px;">
            <button type="submit"name ="searchbtn" class="btn btn-link jbtn" style="position:absolute; margin-top:-90px; margin-left:780px;"><i class="fa fa-search text-info" aria-hidden="true"></i>
            </button>
         </form>
       
      </div>
      <div class="collapse navbar-collapse position-relative mt-5">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="#" class="nav-link position-absolute">
            <img src="image/settings.png" width="25px" class="text-secondary " alt="" style="opacity: .8;margin-top: -115px; margin-left:-100px"> 
            </a>
          </li>
        
            <li class="nav-item ">
            <a href="javascript:;" class="btn btn-link btn-raised btn-fab " data-toggle="dropdown" style="margin-top: -65px; margin-left:-50px">
            <img src="image/apps.png" alt="" style="opacity: .6;width:25px; height:25px; ">
            </a>
            </li>
            <li class="dropdown nav-item mr-2">
            <a href="javascript:;" class="profile-photo dropdown-toggle nav-link" data-toggle="dropdown" style="margin-top: -45px;">
                <div class="profile-photo-small">
                <img src="image/profil.jpg" style="width:30px; height:30px;" alt="Circle Image" class="rounded-circle img-fluid">
                </div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <h6 class="dropdown-header">Dropdown header</h6>
                <a href="javascript:;" class="dropdown-item">Me</a>
                <a href="javascript:;" class="dropdown-item">Settings and other stuff</a>
                <a href="javascript:;" class="dropdown-item">Sign out</a>
            </div>
            </li>
        </ul>
      </div>
    </div>
  </nav>