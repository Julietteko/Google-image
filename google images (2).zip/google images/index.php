
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="image/g.png">
    <title>google images</title>
    <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="css/material-kit.css" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="css/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/input.css">
</head>
<body class="bg-white">
<?php include 'include/navbar.php' ?>



    <div class="container-fluid ">
        <div class="text-center " style="margin-top: 100px;">
            <img src="image/google.png" alt="google images" height="160px" width="250px"> 
        </div>
        <div class="d-flex" >
            <span class="text-info h5" style="margin-left:825px; margin-top:-50px;">images</span>
        </div>
      
        <form action="search.php" method="POST" class="position-relative" >
            <input type="text" class="pl-5 box" name="search" style="padding-right: 130px; height: 47px; width: 598px; margin-left:500px" >
            <i class="material-icons" style="position:absolute; margin-top:-85px; margin-left:520px;opacity: 0.5;">search</i>
            <i class="material-icons"  style="position:absolute; margin-top:-85px; margin-left:968px;opacity: 0.5;">camera_alt</i>
            <img src="image/mic.png" alt="" width="15px" height="23px" style="position:absolute; margin-top:-85px; margin-left:1010px;">
            <button type="submit"name="searchbtn" class="btn btn-link" style="position:absolute; margin-top:-95px; margin-left:1020px;"><i class="fa fa-search text-info" aria-hidden="true"></i>
            </button>
        </form>
    </div>
      
        
    
      

 








     <!--   Core JS Files   -->
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/popper.min.js" type="text/javascript"></script>
  <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="js/moment.min.js"></script>
  <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
  <script src="js/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="js/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="js/material-kit.js" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      materialKit.initFormExtendedDatetimepickers();

      // Sliders Init
      materialKit.initSliders();
    });


    function scrollToDownload() {
      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }
  </script>
</body>
</html>