<?php
session_start();
include 'connexion/connexion.php';

if (isset($_POST["search"]) && !empty($_POST['search'])) {


    $search =  $_POST["search"];
}


?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8" />

    <link rel="icon" type="image/png" href="image/g.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>fleur - Recherche Google</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <!-- https://material.io/resources/icons/?style=outline -->
    <link href="https://fonts.googleapis.com/css2?family=Material+Icons+Outlined" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

    <!-- CSS Files -->
    <link href="css/material-kit.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="slick/slick.css">
    <link rel="stylesheet" type="text/css" href="slick/slick-theme.css">




    <!-- input search css -->
    <link rel="stylesheet" href="css/input.css">

    <style>
        .icon {
            vertical-align: middle;
            opacity: .8;
            font-size: 18px;
        }

        .text {

            opacity: .8;
            font-size: 13px;
            font-family: sans-serif;
        }

        .cont {

            display: inline-block;

            padding: 10px;



        }

        .a {
            color: #1d2124;
            position: relative;
            text-decoration: none;
            padding-bottom: 15px;


        }

        .a:hover {
            color: blue;
        }

        .a::before {
            content: "";
            position: absolute;
            display: block;
            width: 100%;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: blue;
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .a:hover::before {
            transform: scaleX(1);
        }

        .bt {
            border: none;
            background-color: white;
            color: black;
            padding: -10px;
            font-size: 13px;
            cursor: pointer;
        }

        /* Gray */
        .grey {
            border-color: #e7e7e7;
            color: black;
        }

        .grey:hover {
            background: #e7e7e7;
        }

        .ban {
            border: 1px solid rgb(199, 193, 193);
            border-radius: 10px;
            display: inline-flex;

            margin: -8px;
            height: 45px;
            width: auto;
        }


        .text {


            padding-left: 10px;
            padding-right: 10px;
            font-weight: bold;

        }

        .image {
            border-start-start-radius: 10px;
            border-bottom-left-radius: 10px;
            max-width: 100px;

        }

        .card-image {
            max-width: 100%;
            max-height: 180px;
            object-fit: cover;
        }

        .img-card {
            max-width: 100%;
            max-height: 180px;


        }

        .img-card:hover {

            -moz-box-shadow: 0 0 20px #ccc;
            -webkit-box-shadow: 0 0 20px #ccc;
            box-shadow: 0 0 20px #ccc;

        }

        .desc {
            font-size: 12px;
            font-weight: 500;
        }

        .desc:hover {
            text-decoration: underline;
        }

        /* slick css */




        .logo-slider .item {
            background-color: #fff;


        }

        .logo-slider .slick-slide {
            margin: 15px;

        }


        .slick-next:before,
        .slick-prev:before {
            color: black;

        }
    </style>
</head>

<body class="bg-white  ">
    <?php include 'include/header.php' ?>

    <div class="container-fluid" style="margin-top: 80px; margin-right:10px">


        <div class="container ">

            <ul class="navbar-nav d-inline-block text-dark" style="margin-left: 5px;">
                <div class="cont">
                    <a class="a">
                        <i class="material-icons icon">search</i>
                        <span class="text">Tous</span>
                    </a>
                </div>
                
                <div class="cont">
                    <a class="a">
                        <img src="image/iconephoto.jpg" width="20px" alt="">
                        <span class="text">Images</span>
                    </a>
                </div>
                <div class="cont">
                    <a class="a">
                        <i class="material-icons-outlined icon">smart_display</i>
                        <span class="text">Vidéos</span>
                    </a>
                </div>
                <div class="cont">
                    <a class="a">
                        <i class="material-icons-outlined icon">place</i>
                        <span class="text">Maps</span>
                    </a>
                </div>
                <div class="cont">
                    <a class="a">
                        <i class="fa fa-newspaper-o icon" aria-hidden="true"></i>
                        <span class="text">Actualités</span>
                    </a>
                </div>
                <div class="cont">
                    <a class="a">
                        <i class="material-icons icon">more_vert</i>
                        <span class="text">Plus</span>
                    </a>
                </div>

                <div class="cont" style="margin-left: 100px;">
                    <button class="bt grey">Outils</button>
                </div>




            </ul>

        </div>

        <hr style="margin-top: 0px;">

    </div>


    <!-- barre slide-->


    <div class="container-fluid">

        <div class="logo-slider mx-3">
            <?php

            if (isset($_POST["search"]) && !empty($_POST['search'])) {


                $search =  $_POST["search"] ;

                
           //RECHERCHE DANS LA BASE 

                $query = "SELECT * FROM tablefleurs  WHERE (type  LIKE '%{$search}%' OR nom LIKE '%{$search}%')
    ORDER BY `tablefleurs`.`nom` ASC ";

                $result = mysqli_query($connection, $query);

                $num = mysqli_num_rows($result);
                if ($num >= 1) {
                    // RECUPERATION DES DONNEES

                    while ($row = mysqli_fetch_assoc($result)) {

                        $id = $row['id'];
                        $nom = $row['nom'];  
                        $imagefleur = $row['image'];



            ?>

                        <div class="item">
                            <div class="ban">
                                <img src="<?php echo $imagefleur ?>" class="image" alt="..." height="45px" width="45px" style="object-fit: cover;">
                                <pan class="text"> <?php echo $nom ?></span>
                            </div>
                        </div>
            <?php

                    }
                } else {


                    echo '';
                }
            }


            ?>



        </div>
    </div>

    <!-- debut du cadre d'affichage des images et la description -->


    <div class="container-fluid mx-auto row mt-2" >
        <?php

        if (isset($_POST["search"]) && !empty($_POST['search'])) { //verifier si la recherche n'est pas vide


            $search =  $_POST["search"];




            //recherche dans la base de données

            $query = "SELECT * FROM tablefleurs  WHERE nom  LIKE '%$search%' OR type LIKE '%$search%'";
            

            $result = mysqli_query($connection, $query);

            $num = mysqli_num_rows($result);
            if ($num >= 1) {
                // recuperation des données

                while ($row = mysqli_fetch_assoc($result)) {

                    $id = $row['id'];
                    $typefleurs = $row['type'];
                    $nom = $row['nom'];
                    $description = $row['description'];
                    $date_pub = $row['date_pub'];
                    $imagefleur = $row['image'];



        ?>
                  <!-- cadre d'affichage des images et la description -->

                    <a href="description.php?id=<?php echo $row['id']; ?>&search=<?php echo $_POST['search'] ?>" class="text-dark">
                        <div class="d-inline-block  mx-auto  " style="margin-bottom:40px">
                            <div class="img-card mx-2 mb-3 mt-2">
                                <img src="<?php echo $imagefleur ?>" alt="" class="card-image ">
                                <!-- code pour ne pas afficher toute la description -->
                                <span class="desc"><br><?php echo (html_entity_decode(
                                                            substr("$row[nom];", 0, 30)
                                                        ) .
                                                            "...") ?><br><small><?php echo (html_entity_decode(
                                                                                substr("$row[description];", 0, 30)
                                                                            ) .
                                                                                "...") ?> </small></span>
                            </div>

                        </div>
                    </a>
        <?php

                }
            } else {
                $_SESSION['echec'] = "Aucun resultat trouvé";
                // header('Location: search.php');
                echo ' <div class="container">
                        <h6 class="text-danger">Aucun resultat trouvé</h6>
                        </div>';
            }
        }

        mysqli_close($connection);
        ?>





    </div>


    <!-- fin du cadre -->





    <footer class="footer" data-background-color="black" style="margin-top: 500px;">
        <div class="container">
            <nav class="float-left">
                <ul>
                    <li>
                      
                        DigiTech
                        
                    </li>
                    <li>
                        
                           A propos de nous
                        
                    </li>
                    <li>
                        
                            Blog
                        
                    </li>
                    <li>
                        
                            Licences
                        
                    </li>
                </ul>
            </nav>
            <div class="copyright float-right">
                &copy;
                <script>
                    document.write(new Date().getFullYear())
                </script>, made with <i class="material-icons">favorite</i> by
                <a href="https://www.creative-tim.com/" target="_blank">Creative Tim</a> for a better web.
            </div>
        </div>
    </footer>

    <!--   Core JS Files   -->
    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script src="js/popper.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-material-design.min.js" type="text/javascript"></script>
    <script src="js/moment.min.js"></script>
    <!--    Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
    <script src="js/bootstrap-datetimepicker.js" type="text/javascript"></script>
    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="js/nouislider.min.js" type="text/javascript"></script>
    <!--  Google Maps Plugin    -->
    <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
    <script src="js/material-kit.js" type="text/javascript"></script>


    <script src="slick/slick.min.js"></script>
    <script>
        // slide du menu

        $('.logo-slider').slick({

            infinite: false,
            speed: 300,
            slidesToShow: 5,
            slidesToScroll: 3,
            centerMode: false,
            variableWidth: true,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,

                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
                
            ]
        });
    </script>

    
<script>
    // script  pour l'icon de recherche noire
        $(document).ready(function() {
            $(".box").click(function() {
                $(".box").animate({

                    left: '-15px',
                    width: '715px'
                }, 100);
                $(".loup").show();

            });
        });

        $('form').find("input[type=textarea], input[type=password], textarea").each(function(ev) {
            if (!$(this).val()) {
                $(this).attr("placeholder", "Type your answer here");
            }
        });

        
    </script>

</body>

</html>