<?php


session_start();

require_once("connexion/connexion.php");

    if (isset($_POST["searchbtn"])) {
        
        $search = $_POST["search"];

    //RECHERCHE DANS LA BASE 

$query ="SELECT * FROM tablinfofleur WHERE Typedeplante OR Nomfleurs LIKE '%$search%'" ;
$result = mysqli_query($connection, $query);
$num = mysqli_fetch_row($result);
if ($num > 0) {
    // RECUPERATION DES DONNEES

    while($row = mysqli_fetch_assoc($result)){

    $id = $row['IDfleurs'];
    $typefleurs = $row['Typedeplante'];
    $nom = $row['Nomfleurs'];
    $description = $row['Descriptionfleurs'];
    $date_pub = $row['DteEnrgfleurs'];


    // RECUPERATION DE L'IMAGE
    $image = "SELECT * FROM tableinfofleurimage WHERE IDInfofleurs = '$id'";
    $imgresult = mysqli_query($connection, $image);
    $rowimg = mysqli_fetch_assoc($imgresult);
    $imagefleur = $rowimg['Lienfleurs'];
    echo'.$rowimg["Lienfleurs"] ';

}
}
else {
    $_SESSION['echec'] ="Aucun resultat trouvé";
    header('Location: search.php');
}


mysqli_close($connection);

    }


?>